<?php
/**
 * Template Library Header Tabs
 */
?>
<label>
	<input type="radio" value="{{ slug }}" name="ma-el-modal-header-tab">
	<span>{{ title }}</span>
</label>