<?php
/**
 * Templates Item Preview
 */
?>
<div class="ma-el-item-notice"></div>
<div class="ma-el-item-preview-iframe">
    <iframe></iframe>
</div>
