<?php
/**
 * Template Library Header
 */
?>
<div id="ma-el-template-modal-header-logo-area"></div>
<div id="ma-el-template-modal-header-tabs"></div>
<div id="ma-el-template-modal-header-actions"></div>
<div id="ma-el-template-modal-header-close-modal" class="elementor-template-library-header-item" title="<?php echo __(
        'Close', MELA_TD ); ?>">
	<i class="eicon-close" title="Close"></i>
</div>