<div class="jltma-pop-contents-head">
    <div class="jltma-popup-head-content float-left">
        <h3>
            <?php echo esc_html__('Header, Footer & Comment Template', JLTMA_TD);?>
        </h3>
    </div>
    <div class="jltma-pop-close float-right">
        <button class="close-btn" data-dismiss="modal">x</button>
    </div>
</div>  
