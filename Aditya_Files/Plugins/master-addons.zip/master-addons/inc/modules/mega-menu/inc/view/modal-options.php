<div class="modal fade" id="jltma_megamenu_modal" tabindex="-1" role="dialog" aria-hidden="true" >    
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="jltma-popup-contents">
        
                <?php include 'modal-header.php';?>

                <?php include 'modal-body.php';?>

            </div> <!-- jltma-popup-contents -->
        </div>
    </div>
</div>

<?php include 'modal-iframe.php';?>