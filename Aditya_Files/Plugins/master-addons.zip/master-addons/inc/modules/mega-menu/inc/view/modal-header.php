<div class="jltma-pop-contents-head">
    <div class="jltma-pop-close float-left">
        <button class="close-btn" data-dismiss="modal">x</button>
    </div>
    <div class="jltma-pop-save float-right">
        <input type="hidden" id="jltma-menu-modal-menu-id">
        <input type="hidden" id="jltma-menu-modal-menu-has-child">
        <span class='spinner'></span>
        <?php echo get_submit_button(esc_html__('Save', MELA_TD), 'jltma-menu-item-save save-btn','', false); ?>
    </div>
    <span id="jltma-menu-modal-spinner" class='spinner'></span>
</div>  
