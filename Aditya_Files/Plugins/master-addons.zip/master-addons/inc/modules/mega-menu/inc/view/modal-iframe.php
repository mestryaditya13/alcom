<div class="modal fade" id="jltma-mega-menu-builder-modal" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <button class="jltma_close" type="button" data-dismiss="modal">
                    <svg  class="icon--search" id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 40 40"><defs><style>.cls-1{fill:url(#linear-gradient);}.cls-2{fill:url(#linear-gradient-2);}.cls-3{fill:#fff;}</style><linearGradient id="linear-gradient" y1="40" x2="40" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#c6027a"/><stop offset="1" stop-color="#143df4"/></linearGradient><linearGradient id="linear-gradient-2" y1="40" x2="40" gradientUnits="userSpaceOnUse"><stop offset="1" stop-color="#c6027a"/><stop offset="1" stop-color="#143df4"/></linearGradient></defs><title>close_03</title><rect class="cls-1" width="40" height="40"/><rect class="cls-2" width="40" height="40"/><path class="cls-3" d="M22.12,20l6.72-6.72a1.5,1.5,0,1,0-2.12-2.12L20,17.88l-6.72-6.72a1.5,1.5,0,1,0-2.12,2.12L17.88,20l-6.72,6.72a1.5,1.5,0,1,0,2.12,2.12L20,22.12l6.72,6.72a1.5,1.5,0,1,0,2.12-2.12Z"/></svg>
                </button>
                <iframe id="jltma-menu-builder-iframe" src="<?php echo esc_url(get_rest_url() . 'masteraddons/v2/mastermega-content/jltma_content_editor/megamenu/menuitem'); ?>" frameborder="0"></iframe>
            </div>
        </div>
    </div>
</div>