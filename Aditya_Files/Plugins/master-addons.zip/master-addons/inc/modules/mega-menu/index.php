<?php

/**
 * Plugin Name:	Master Mega Menu
 * Description: Mega Menu for Elementor by Master Addons
 * Plugin URI:  https://master-addons.com/megamenu
 * Version:     1.0.0
 * Author:      Jewel Theme
 * Author URI:  https://master-addons.com
 * License:		GPL-2.0+
 * License URI:	http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:	mmm
 * Domain Path:	/languages
 */

require plugin_dir_path(__FILE__) . 'mega-menu.php';
