"use strict";

stm_lms_components['navigation'] = {
  template: '#stm-lms-dashboard-navigation'
};