"use strict";

(function ($) {
  $(document).ready(function () {
    $('body').addClass('single-user-assignment');
  });
})(jQuery);