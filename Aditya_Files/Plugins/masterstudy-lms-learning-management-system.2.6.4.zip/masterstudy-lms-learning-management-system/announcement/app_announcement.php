<div class="app_announcement">
    <div class="logo">
        <img src="<?php echo STM_LMS_URL; ?>/assets/img/ms-logo.svg" width="185" />
    </div>
    <div class="message">
        LMS Mobile App - Flutter iOS & Android is available now
    </div>
    <div class="stm-buttons">
        <a href="https://stylemixthemes.com/masterstudy-education-app/" target="_blank" class="stm-button">More details</a>
        <a href="#" class="close"><i class="fa fa-times-circle"></i></a>
    </div>
</div>